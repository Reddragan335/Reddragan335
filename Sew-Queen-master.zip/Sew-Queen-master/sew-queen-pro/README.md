```js
Sew Queen Whatsapp Bot                       

🎲 Telegram: 't.me/RavinduManoj'
Facebook: 'https://www.facebook.com/ravindu.manoj.79'
Licensed under the  GPL-3.0 License;

Coded By Ravindu Manoj

"You Can't Use Cloned Or Forked version of Sew Queen.. So Don't waste your Time For Do it... [Ravindu Manoj]"

 'This Folder Will Automate After Deploy Your Bot'
```
