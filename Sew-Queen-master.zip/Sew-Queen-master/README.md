<div align="center"><h1>❖❖❖❖❖   𝐒𝐄𝐖 𝐐𝐔𝐄𝐄𝐍   ❖❖❖❖❖</h1><a href="https://github.com/ravindu01manoj/Sew-Queen"><img src="https://github.com/ravindu01manoj/ravindu01manoj/blob/e30459858952812db2b9b479cbc6eeb7603bb494/sewqueenimg/main.jpg" width="250" height="250"></a><h3>✬✬ Sew Queen Is World Best Whatsapp Bot Ever ✬✬</h3></div>


***

<p align="center"><a href="httsp://github.com/ravindu01manoj/Sew-Queen"><img src="https://img.shields.io/docker/pulls/ravindu01manoj/sewqueen?style=for-the-badge&logo=docker&label=Docker+Pulls&color=blueviolet"></a><a href="https://github.com/ravindu01manoj/Sew-Queen"><img src="https://img.shields.io/docker/image-size/ravindu01manoj/sewqueen?style=for-the-badge&logo=docker&label=Image Size&color=blueviolet"></a></p><p align="center"><a href="https://github.com/ravindu01manoj/Sew-Queen"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2Fravindu01manoj%2FSew-Queen&count_bg=%2379C83D&title_bg=%23555555&icon=gitpod.svg&icon_color=%23E7E7E7&title=Views&edge_flat=false" alt="Views"/></a></a><a href="https://github.com/ravindu01manoj/Sew-Queen/fork"><img src="https://img.shields.io/github/forks/ravindu01manoj/Sew-Queen?label=Fork&style=social"></a><a href="https://github.com/ravindu01manoj/Sew-Queen/stargazers"><img src="https://img.shields.io/github/stars/ravindu01manoj/Sew-Queen?style=social"></a></p><p align="center"><a href="httsp://github.com/ravindu01manoj/Sew-Queen"><img src="https://img.shields.io/github/repo-size/ravindu01manoj/Sew-Queen?color=00ff00&label=Repo%20Size&style=flat-square"></a><a href="httsp://github.com/ravindu01manoj/Sew-Queen"><img src="https://img.shields.io/github/license/ravindu01manoj/Sew-Queen?color=00ff00&label=License&style=flat-square"></a><a href="httsp://github.com/ravindu01manoj/Sew-Queen"><img src="https://img.shields.io/github/languages/top/ravindu01manoj/Sew-Queen?color=00ff00&label=Javascript&style=flat-square"></a><a href="httsp://github.com/ravindu01manoj/Sew-Queen"><img src="https://img.shields.io/badge/Programmer-Ravindu%20Manoj-blueviolet"></a></p><p align="center"><a href="https://t.me/RavinduManoj"><img src="https://img.shields.io/badge/Contact%20Me%20On%20Telegrame-Ravindu%20Manoj-success"></a></p>
<div align="center"><img src="https://profile-counter.glitch.me/ravindu01manoj/count.svg" /><br>Profile Viewers</div>

***

# How To Deploy And Deploy Password
<div align="left"><a href="https://youtu.be/AKU7YVXxMbM"><img src="https://github.com/ravindu01manoj/ravindu01manoj/blob/main/media/20210814_230626.png" width="500" ></a></div>


***
> scan  QR Code ✏
<div align="left"><a href="https://replit.com/@RavinduManoj/Queen-Sew-QR-Code"><img src="https://i.ibb.co/5WRBdGh/ab1985860df7.jpg" width="150" ></a></div>

---
> Deploy Your Bot On Heroku ✏
<div align="left"><a href="https://github.com/ravindu01manoj/ravindu01manoj/blob/main/SEW.md"><img src="https://github.com/ravindu01manoj/ravindu01manoj/blob/main/media/Heroku_logo.svg.png" width="150" ></a></div>

***
# Deployment link not working?

> If you do not have a Github account, create a new [Github](https://github.com/signup?ref_cta=Sign+up&ref_loc=header+logged+out&ref_page=%2F&source=header-home) account

> Now Click The [Fork](https://github.com/ravindu01manoj/Sew-Queen/fork)

> Now Copy This Url https://heroku.com/deploy?template=https://github.com/ravindu01manoj/Sew-Queen.git and change ravindu01manoj/Sew-Queen with your user name and repo name

> Now Deploy Sew Queen With Your Own Url.

> more ... ↓↓↓

<div align="left"><a href="https://youtu.be/H_er-5qdFMM"><img src="https://github.com/ravindu01manoj/ravindu01manoj/blob/main/sewqueenimg/yt.jpg" width="150" ></a></div>

***
<div aline='left'><h2> SEW QUEEN TEAM </h2></div>

***


<table><tr><th>Ms:Sew</th><th>Ravindu Manoj </th></tr><tr><td><a href="https://github.com/ravindu01manoj"><img src="https://github.com/ravindu01manoj/ravindu01manoj/blob/b5c48b989ad4df7239773217a3a4d58dc41fb494/media/IMG_20211117_145806.jpg" width="180" alt="Sew Queen"></a></td><td><a href="https://github.com/ravindu01manoj"><img src="https://github.com/ravindu01manoj/ravindu01manoj/blob/b5c48b989ad4df7239773217a3a4d58dc41fb494/media/temp_user_profile1621662133773.jpeg" width="180" alt="Ravindu Manoj"></a></td></tr><tr><td>Owner</td><td>Developer & Owner </td></tr></table><table><tr><th>Muthu</th><th>Dilusha</th><th>Umeda</th></tr><tr><td><a href="https://github.com/ravindu01manoj"><img src="https://github.com/ravindu01manoj/ravindu01manoj/blob/b5c48b989ad4df7239773217a3a4d58dc41fb494/media/3e3b65c1117c61427e00843254eaf84c.jpg" width="180" alt="Muthu"></a></td><td><a href="http://github.com/dilushamandila"><img src="https://avatars.githubusercontent.com/u/90194808?v=4" width="180" alt="Dilusha"></a></td><td><a href="http://github.com/umedaewandee"><img src="https://github.com/ravindu01manoj/ravindu01manoj/blob/b5c48b989ad4df7239773217a3a4d58dc41fb494/media/IMG_20211117_150039.jpg" width="180" alt="Umeda"></a></td></tr><tr><td>Voice & Idea </td><td> Graphics & Group Management</td><td>Group Management & Idea</td></tr></table>


***
<div align="center"><h1>✬✬ Sew Queen Is World Best Whatsapp Bot Ever ✬✬</h1><a href="https://github.com/ravindu01manoj/Sew-Queen"><img src="https://github.com/ravindu01manoj/ravindu01manoj/blob/1d9ff8a76d20d4d151780c68c59beeb68b318e88/media/ezgif.com-video-to-gif%20(1).gif" width="450"></a></div>

***
> [Documentation](https://github.com/ravindu01manoj/Sew-Queen/wiki/Commands)
: All Commands

> [Documentation](https://github.com/ravindu01manoj/Sew-Queen/wiki/Extrenal-Commands)
: Official Extrenal Commands

> [Documentation](https://github.com/ravindu01manoj/Sew-Queen/wiki/Add-Your-Own-Cmd-For-Sew-Queen-Whatsapp-Bot)
: How To Add Your Own Command For Sew Queen 

> [Documentation](https://github.com/ravindu01manoj/Sew-Queen/wiki/ALL-Words-(Voice-Reply))
: All Words In Voice Reply

***
> Another Way To Get Qr ✏

# You Can Get Qr Easily Using Another Sew Queen Bot
# Get Qr As Image To Use .getqr

> termux code for qr✏


```
$ pkg upgrade && pkg update
$ pkg install nodejs && pkg install git
```

```
$ git clone https://github.com/Sew01RaviduManoj01KingAndQueen/sew.git
$ cd qr
$ npm i
$ node sew.js

```
```
$ cd qr
$ node sew.js
```
